
#!/bin/bash
echo "// Generate Spring Boot API for appointment booking" >> ./backend/src/main/java/com/healthcare/controller/AppointmentController.java
echo "// Write JUnit test for createAppointment() method" >> ./backend/src/test/java/com/healthcare/controller/AppointmentControllerTest.java
